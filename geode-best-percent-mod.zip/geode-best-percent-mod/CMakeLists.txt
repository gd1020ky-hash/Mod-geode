cmake_minimum_required(VERSION 3.21)
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Geode mods are built for both Apple Silicon and Intel on macOS.
if ("${CMAKE_SYSTEM_NAME}" STREQUAL "iOS" OR IOS)
    set(CMAKE_OSX_ARCHITECTURES "arm64")
else()
    set(CMAKE_OSX_ARCHITECTURES "arm64;x86_64")
endif()
set(CMAKE_CXX_VISIBILITY_PRESET hidden)

# The project name becomes the name of the compiled binary.
project(BestPercentPause VERSION 1.0.0)

# Compile every .cpp file inside src/ (recursively).
file(GLOB_RECURSE SOURCES CONFIGURE_DEPENDS src/*.cpp)

# Build the mod as a shared library (a .dll / .so / .dylib).
add_library(${PROJECT_NAME} SHARED ${SOURCES})

# The Geode SDK must be discoverable through the GEODE_SDK environment variable.
if (NOT DEFINED ENV{GEODE_SDK})
    message(FATAL_ERROR "Unable to find Geode SDK! Please define the GEODE_SDK environment variable to point to Geode")
else()
    message(STATUS "Found Geode: $ENV{GEODE_SDK}")
endif()

add_subdirectory($ENV{GEODE_SDK} ${CMAKE_CURRENT_BINARY_DIR}/geode)

# Wire up Geode's include paths, link the SDK, and register the mod resources.
setup_geode_mod(${PROJECT_NAME})
