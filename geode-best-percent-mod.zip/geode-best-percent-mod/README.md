# Best Percent & Quick Restart

A small, clean **Geode SDK** mod for **Geometry Dash** (C++).

It shows your **best percentage** and **attempt count** in the pause menu and on the
level info screen, and adds a **configurable hotkey** (default `R`) that instantly
restarts the level.

> ⚠️ **This is source code, not a compiled binary.**
> Building a Geode mod requires the **Geode SDK** plus a full **Geometry Dash C++
> toolchain** (MSVC on Windows, Clang/Xcode on macOS, the Android NDK for Android).
> That toolchain **cannot be installed or run in the environment this project was
> generated in**, so the project is delivered **ready to build** rather than as a
> finished `.geode` file. Follow the steps below on your own machine (or let the
> included GitHub Actions workflow build it for you).

---

## Features

| Feature | Where | Notes |
| --- | --- | --- |
| Best percentage | Pause menu + level info screen | Uses `GJGameLevel::getNormalPercent()` |
| Attempt count | Pause menu + level info screen | Reads `GJGameLevel::m_attempts` |
| Quick restart hotkey | In-game | Default `R`, fully rebindable |
| Restart button | Pause menu | Same action as the hotkey |
| Death / completion logging | Geode log | Logs the % you died at and your stats on completion |

### Settings (editable in-game under **Mods → Best Percent & Quick Restart → Settings**)

| Setting | Type | Default | Description |
| --- | --- | --- | --- |
| Show best percentage | `bool` | on | Show your best normal-mode percentage. |
| Show attempt count | `bool` | on | Show how many attempts you have. |
| Quick restart keybind | `keybind` | `R` | Key that instantly restarts the level. |
| Restart from the beginning | `bool` | on | Restart from 0% instead of the last checkpoint. |

---

## Project structure

```
best-percent-pause/
├── mod.json                          # Mod metadata + settings (Geode reads this)
├── CMakeLists.txt                    # Geode SDK build script
├── about.md                          # Description shown in the in-game mod list
├── changelog.md                      # Version history
├── .gitignore
├── .github/
│   └── workflows/
│       └── build.yml                 # Standard Geode CI (builds all platforms)
└── src/
    ├── main.cpp                      # Entry point: registers the keybind listener
    ├── Utils.hpp                     # Shared helpers (read stats, quick restart)
    ├── PauseLayerHook.cpp            # Pause menu: stats label + Restart button
    ├── LevelInfoLayerHook.cpp        # Level info screen: stats label
    └── PlayLayerHook.cpp             # Gameplay: death / completion logging
```

---

## Build instructions

### 1. Install the Geode CLI

The Geode CLI is a single executable that manages the SDK and builds mods.

- **Windows / macOS / Linux:** download the CLI from
  <https://github.com/geode-sdk/cli/releases> and put it on your `PATH`.
- **Windows (winget):** `winget install GeodeSDK.GeodeCLI`
- Verify it works:

  ```sh
  geode --version
  ```

### 2. Install the C++ toolchain

- **Windows:** install **Visual Studio 2022** (or the *Build Tools for Visual
  Studio 2022*) with the **Desktop development with C++** workload.
- **macOS:** install **Xcode** and its command line tools (`xcode-select --install`).
- **Linux:** install `clang`, `cmake` and `ninja` from your package manager.

### 3. Install the Geode SDK

```sh
geode sdk install
```

This downloads the SDK and sets the `GEODE_SDK` environment variable that
`CMakeLists.txt` looks for. Confirm it is set:

```sh
geode sdk path
```

> If you are on Linux and want the full toolchain set up for you, run
> `geode sdk install-linux` instead.

### 4. Build the mod

From the root of this project (the folder containing `mod.json`):

```sh
geode build
```

The first build downloads dependencies and may take a few minutes. When it
finishes, the compiled mod is written to:

```
build/gd1020ky.best-percent-pause.geode
```

To build for a specific platform (e.g. Android):

```sh
geode build --target Android64
```

### 5. Install the `.geode` file into Geometry Dash

1. Locate your Geometry Dash mods folder:
   - **Windows:** `%LOCALAPPDATA%\GeometryDash\geode\mods`
   - **macOS:** `~/Library/Application Support/GeometryDash/geode/mods`
   - **Android:** `/storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods`
2. Copy `gd1020ky.best-percent-pause.geode` into that folder.
3. Launch Geometry Dash. The mod appears under **Mods** in the main menu.

> **Easier alternative:** run `geode build --install` (or use the Geode VS Code
> extension) to build and install in one step.

---

## Building with GitHub Actions (no local toolchain needed)

The included workflow at `.github/workflows/build.yml` builds the mod for
**Windows, macOS, iOS, Android32 and Android64** on every push, using Geode's
official `geode-sdk/build-geode-mod` action.

1. Push this project to a GitHub repository.
2. Open the **Actions** tab — the *Build Geode Mod* workflow runs automatically.
3. Download the **Build Output** artifact from the finished run; it contains the
   combined `.geode` file ready to install.

This is the easiest route if you do not want to set up a C++ toolchain locally.

---

## How the code works

- **`main.cpp`** — uses `$on_game(Loaded)` to register
  `listenForKeybindSettingPresses("restart-keybind", ...)`, which fires whenever
  the user presses their bound key. It ignores key-repeat and key-up events and
  only acts while a `PlayLayer` exists.
- **`PauseLayerHook.cpp`** — `$modify(BPPauseLayer, PauseLayer)` hooks
  `customSetup()` (called after the vanilla pause menu is built) and adds a
  `CCLabelBMFont` with the stats plus a `CCMenuItemSpriteExtra` Restart button.
- **`LevelInfoLayerHook.cpp`** — `$modify(BPLevelInfoLayer, LevelInfoLayer)` hooks
  `init(GJGameLevel*, bool)` and adds a small stats label in the corner.
- **`PlayLayerHook.cpp`** — `$modify(BPPlayLayer, PlayLayer)` hooks
  `destroyPlayer()` and `levelComplete()` to log progress via `geode::log`.
- **`Utils.hpp`** — shared helpers: `getBestPercent()`, `getAttempts()`,
  `buildStatsString()` and `quickRestart()`.

All settings are read at runtime with `Mod::get()->getSettingValue<T>("...")`, so
toggling them in the in-game settings page takes effect immediately.

---

## Troubleshooting

| Problem | Fix |
| --- | --- |
| `Unable to find Geode SDK!` | Run `geode sdk install`, then reopen your terminal so `GEODE_SDK` is set. |
| `geode: command not found` | The CLI is not on your `PATH` — reinstall it or add its folder to `PATH`. |
| Build fails on Windows | Make sure the **Desktop development with C++** workload is installed in Visual Studio 2022. |
| Mod does not appear in-game | Confirm the `.geode` file is in the `geode/mods` folder and that your Geode version matches `mod.json` (`5.0.0`). |
| Version mismatch warning | Update Geode, or change the `geode` / `gd` values in `mod.json` to match your installed versions. |

---

## License

MIT — do whatever you like with it.
