# Best Percent & Quick Restart

A small quality-of-life mod for Geometry Dash.

## Features

- **Best percentage in the pause menu** — see exactly how far you have gotten on the level without leaving it.
- **Attempt count in the pause menu** — know how many tries you have sunk into a level.
- **Stats on the level info screen** — check your best run before you even press Play.
- **Quick restart hotkey** — bind any key (default `R`) to instantly restart the level, from the start or from your last checkpoint.
- **Restart button** — the same action, available from the pause menu.

## Settings

| Setting | Type | Default | Description |
| --- | --- | --- | --- |
| Show best percentage | bool | on | Show your best normal-mode percentage. |
| Show attempt count | bool | on | Show how many attempts you have. |
| Quick restart keybind | keybind | `R` | Key that instantly restarts the level. |
| Restart from the beginning | bool | on | Restart from 0% instead of the last checkpoint. |
