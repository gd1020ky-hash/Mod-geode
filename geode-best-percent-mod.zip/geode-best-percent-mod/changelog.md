# Changelog

## v1.0.0

- Initial release.
- Added a best-percentage and attempt-count label to the pause menu.
- Added a stats label to the level info screen.
- Added a configurable quick-restart keybind (default `R`).
- Added a Restart button to the pause menu.
- Added logging of death percentage and level completion stats.
