/**
 * LevelInfoLayer hook
 * -------------------
 * Adds a small stats label to the level info screen (the page you see before
 * pressing Play on a level), so you can check your best run without entering
 * the level first.
 */

#include <Geode/Geode.hpp>
#include <Geode/modify/LevelInfoLayer.hpp>
#include "Utils.hpp"

using namespace geode::prelude;

class $modify(BPLevelInfoLayer, LevelInfoLayer) {

    /**
     * `LevelInfoLayer::init` takes the level being viewed and a `challenge`
     * flag. We keep the exact signature so the hook is registered correctly.
     */
    bool init(GJGameLevel* level, bool challenge) {
        if (!LevelInfoLayer::init(level, challenge)) return false;

        auto stats = BestPercent::buildStatsString(level);
        if (stats.empty()) return true;

        auto winSize = CCDirector::get()->getWinSize();

        auto label = CCLabelBMFont::create(stats.c_str(), "goldFont.fnt");
        label->setScale(0.45f);
        // Bottom-left corner, out of the way of the vanilla UI.
        label->setPosition({ 90.f, 18.f });
        label->setID("best-percent-info-label"_spr);
        this->addChild(label);

        return true;
    }
};
