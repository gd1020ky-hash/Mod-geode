/**
 * PauseLayer hook
 * ---------------
 * Adds a stats label (best percentage + attempt count) and a "Restart" button
 * to the in-game pause menu.
 */

#include <Geode/Geode.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include "Utils.hpp"

using namespace geode::prelude;

/**
 * `$modify` extends a Geometry Dash class. The first argument is the name of
 * our own class (used for button callbacks), the second is the class we hook.
 *
 * We hook `customSetup`, which the game calls after the pause menu has been
 * built, so all of the vanilla nodes already exist and we can safely add ours.
 */
class $modify(BPPauseLayer, PauseLayer) {

    void customSetup() {
        // Always call the original function first so the vanilla pause menu
        // is fully initialised before we touch it.
        PauseLayer::customSetup();

        auto playLayer = PlayLayer::get();
        if (!playLayer || !playLayer->m_level) return;

        auto level = playLayer->m_level;
        auto winSize = CCDirector::get()->getWinSize();

        // --- Stats label -------------------------------------------------
        auto stats = BestPercent::buildStatsString(level);
        if (!stats.empty()) {
            auto label = CCLabelBMFont::create(stats.c_str(), "bigFont.fnt");
            label->setScale(0.5f);
            label->setPosition({ winSize.width / 2.f, winSize.height - 24.f });
            // Node IDs are a Geode feature: they let other mods find our nodes.
            label->setID("best-percent-stats-label"_spr);
            this->addChild(label);
        }

        // --- Quick restart button ----------------------------------------
        // A plain text button keeps us independent of any specific sprite frame.
        auto restartButton = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Restart"),
            this,
            menu_selector(BPPauseLayer::onQuickRestart)
        );
        restartButton->setID("quick-restart-button"_spr);

        auto menu = CCMenu::create();
        menu->addChild(restartButton);
        menu->setPosition({ winSize.width / 2.f, winSize.height - 58.f });
        menu->setID("quick-restart-menu"_spr);
        this->addChild(menu);
    }

    /**
     * Button callback. Button callbacks in GD always have the signature
     * `void(CCObject*)`.
     */
    void onQuickRestart(CCObject*) {
        // Unpause first so the game is running again, then restart.
        this->onResume(nullptr);
        BestPercent::quickRestart();
    }
};
