/**
 * PlayLayer hook
 * --------------
 * Tracks the player's progress while a level is being played and logs it.
 * This is what makes the mod useful for debugging your own runs, and it also
 * demonstrates hooking a gameplay class rather than a menu class.
 */

#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include "Utils.hpp"

using namespace geode::prelude;

class $modify(BPPlayLayer, PlayLayer) {

    /**
     * Called by the game whenever the player dies. We log the percentage the
     * player reached so it shows up in the Geode console / log file.
     */
    void destroyPlayer(PlayerObject* player, GameObject* object) {
        // Read the percentage *before* calling the original, because the
        // original resets the level state.
        int percent = static_cast<int>(this->getCurrentPercent());
        log::debug("Player died at {}%", percent);

        PlayLayer::destroyPlayer(player, object);
    }

    /**
     * Called when the level is completed. We log the final percentage and the
     * player's best, which is handy for confirming the mod reads the right
     * values.
     */
    void levelComplete() {
        if (this->m_level) {
            log::info(
                "Level complete! Best: {}% | Attempts: {}",
                BestPercent::getBestPercent(this->m_level),
                BestPercent::getAttempts(this->m_level)
            );
        }
        PlayLayer::levelComplete();
    }
};
