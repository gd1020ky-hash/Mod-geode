#pragma once

#include <Geode/Geode.hpp>

using namespace geode::prelude;

/**
 * Small shared helpers used by the hooks in this mod.
 *
 * Keeping the "read the level's stats" logic in one place means the pause menu,
 * the level info screen and the quick-restart code all agree on what
 * "best percentage" and "attempts" mean.
 */
namespace BestPercent {

    /**
     * Returns the player's best normal-mode percentage on a level (0-100).
     *
     * `GJGameLevel::getNormalPercent()` is the same value the game itself uses
     * for the percentage shown on the level info screen, so we do not have to
     * touch the raw `m_normalPercent` seed value ourselves.
     */
    inline int getBestPercent(GJGameLevel* level) {
        if (!level) return 0;
        return level->getNormalPercent();
    }

    /**
     * Returns how many attempts the player has on a level.
     *
     * `m_attempts` is a `geode::SeedValueRSV`, a small wrapper Geode uses to
     * keep the value in sync with the game's save data. `.value()` unwraps it.
     */
    inline int getAttempts(GJGameLevel* level) {
        if (!level) return 0;
        return level->m_attempts.value();
    }

    /**
     * Builds the "Best: 42%   |   Attempts: 137" string according to the
     * user's settings. Returns an empty string when both parts are disabled.
     */
    inline std::string buildStatsString(GJGameLevel* level) {
        auto mod = Mod::get();
        bool showPercent = mod->getSettingValue<bool>("show-best-percent");
        bool showAttempts = mod->getSettingValue<bool>("show-attempts");

        std::string text;
        if (showPercent) {
            text += fmt::format("Best: {}%", getBestPercent(level));
        }
        if (showAttempts) {
            if (!text.empty()) text += "   |   ";
            text += fmt::format("Attempts: {}", getAttempts(level));
        }
        return text;
    }

    /**
     * Restarts the currently running level.
     *
     * When `restart-from-start` is enabled we call `resetLevelFromStart()` so
     * the player always goes back to 0% (ignoring practice-mode checkpoints);
     * otherwise `resetLevel()` respects the last checkpoint.
     */
    inline void quickRestart() {
        auto playLayer = PlayLayer::get();
        if (!playLayer) return;

        if (Mod::get()->getSettingValue<bool>("restart-from-start")) {
            playLayer->resetLevelFromStart();
        } else {
            playLayer->resetLevel();
        }
    }

} // namespace BestPercent
