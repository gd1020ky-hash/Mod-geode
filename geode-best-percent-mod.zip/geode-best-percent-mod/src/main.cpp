/**
 * Best Percent & Quick Restart
 * ----------------------------
 * A small Geode mod for Geometry Dash that:
 *   1. Shows the level's best percentage and attempt count in the pause menu
 *      and on the level info screen.
 *   2. Adds a configurable hotkey that instantly restarts the level.
 *
 * This file is the mod's entry point: it registers the keybind listener that
 * powers the quick-restart hotkey. The actual UI hooks live in the other
 * source files (PauseLayerHook.cpp, LevelInfoLayerHook.cpp, PlayLayerHook.cpp).
 */

#include <Geode/Geode.hpp>
#include "Utils.hpp"

using namespace geode::prelude;

/**
 * `$on_game(Loaded)` runs once, right after Geode has finished loading the game
 * and this mod. It is the right place to register global listeners such as
 * keybinds, because the game is guaranteed to be ready at this point.
 */
$on_game(Loaded) {
    log::info("Best Percent & Quick Restart loaded!");

    /**
     * `listenForKeybindSettingPresses` wires a `keybind` setting from mod.json
     * to a callback. The user can rebind it from the mod's settings page, and
     * the callback fires with the current key state.
     *
     * Parameters of the callback:
     *   - keybind:   the keybind that was pressed
     *   - down:      true when the key goes down, false when it is released
     *   - repeat:    true for OS key-repeat events (we ignore those)
     *   - timestamp: when the event happened
     */
    listenForKeybindSettingPresses("restart-keybind", [](Keybind const& keybind, bool down, bool repeat, double timestamp) {
        // Only act on the initial press, never on key-repeat or key-up.
        if (!down || repeat) return;

        // Only restart while a level is actually being played.
        if (!PlayLayer::get()) return;

        log::debug("Quick restart triggered by keybind");
        BestPercent::quickRestart();
    });
}
